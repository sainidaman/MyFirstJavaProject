package com.Calculations;

public class TestCalculator {

	public static void main(String[] args) {
		
		
		Calculator c3=new Calculator();
		
		c3.addition(5900, 7900);
		c3.Average(5900, 7900);
		c3.calcDiscount(5900, 7900);
	}

}

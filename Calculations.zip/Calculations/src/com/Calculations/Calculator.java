package com.Calculations;

public class Calculator {
	
	
	//Task 1 : Pratiksha'a code returning Sum
	double addition(double n1,double n2)
	{
		double sum=n1+n2;
		//System.out.println("Sum is : "+ sum);
		return sum;
	}
	
	//task2: Pavan's Code returns average
	double Average(double x, double y)
	{
		Calculator c1=new Calculator();
		double result= c1.addition(x, y);
		double avg=result/2;
		//System.out.println("Average is : "+ avg);
		return avg;
	}
	
	//Task3: Tejas Code returns nothing
	
	void calcDiscount(double a, double b)
	{
		Calculator c2=new Calculator();
		double average=c2.Average(a, b);
		double disc=average*15/100;
		System.out.println(disc);
	}

}
